<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações
// com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define('DB_NAME', 'academiamovetech');

/** Usuário do banco de dados MySQL */
define('DB_USER', 'academiamovetech');

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', '4GhdY9wcXx9I5cei');

/** Nome do host do MySQL */
define('DB_HOST', 'localhost');

/** Charset do banco de dados a ser usado na criação das tabelas. */
define('DB_CHARSET', 'utf8mb4');

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'QNsbKL{p:<sS7B}Np([InXR?dOEM((DwSu-RsYHl@gsC2v~<lSs1+:wdZ67c2g)f');
define('SECURE_AUTH_KEY',  'Yqb*. >in*ef&BsYfE<vcV8}wag3z5TE9[5Gh8HV$Ds*u|>H/q4[b6v<M_3u]yZX');
define('LOGGED_IN_KEY',    ']bRN``7+nxUQTH _91`?$o}Wf{0I_.WSC9n`UFq+jj,Z1.q#ZS{:Rb%7>EuZ:~}b');
define('NONCE_KEY',        '9gL;BI20K[GnTYp{Ke*WiVxC#&ZsD9 j6errO/?Ld5&s6|+CjyX5!ym/HJ?Vn(GW');
define('AUTH_SALT',        'EsS:Ck;Z,1!|U?/]|G{bv3MfY/^1bL:u JyN~r@)MStYFX+;J>T8Xs,f,VjtIX.F');
define('SECURE_AUTH_SALT', '#FoJ$-`*]ss-cJD 4(H0_F*gav#)FM[DpjrWGm$3U)%SB!W1AoOg~j$98IyPfRGj');
define('LOGGED_IN_SALT',   'Nhr7]SB4sChX:gkcQZ}p!cm_3JY,)u5#HjZ}IEi69jXR)r*1bB@M8a1$v)U+ZZ{t');
define('NONCE_SALT',       'uG&t`}.@B@DwuNIE0yXC9>^qxEW`M[e(AC>Lr0|&Q.29FyCXvI-wE`HH1V((7O0)');

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix  = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
